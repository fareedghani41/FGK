using System.Windows;

namespace FgAssistantCompanion;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void PairButton_Click(object sender, RoutedEventArgs e)
    {
        var code = PairingCode.Text.Trim();
        if (code.Length < 6)
        {
            StatusText.Text = "Enter a valid one-time pairing code.";
            return;
        }

        StatusText.Text =
            "Pairing UI is ready, but the authenticated Android pairing service is not implemented in this starter. No connection was made.";
    }
}
