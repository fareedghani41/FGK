using System.Windows;

namespace FgAssistantCompanion;

public partial class App : Application
{
}
