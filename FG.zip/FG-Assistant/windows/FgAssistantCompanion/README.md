# F G Assistant Windows Companion (starter)

Target: Windows 10/11 with .NET 8 Desktop Runtime.

Open `FgAssistantCompanion.csproj` in Visual Studio 2022 or build with:
`dotnet build FgAssistantCompanion.csproj`

This is a UI scaffold only. It does not yet establish a network connection or execute Android/Windows commands. Implementing pairing requires a reviewed authenticated protocol, short-lived pairing codes, key rotation, and user-visible session controls.
