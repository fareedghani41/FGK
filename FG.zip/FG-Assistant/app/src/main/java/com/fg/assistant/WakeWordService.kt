package com.fg.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * User-started, visible wake-phrase listener.
 * Uses Android's speech-recognition service to detect the phrase "Hey F G".
 * Device/recognizer availability and OEM background limits affect reliability.
 * Audio is processed by the selected Android recognition provider; this app does
 * not save recordings or send raw audio to its own server.
 */
class WakeWordService : Service(), RecognitionListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var restarting = false
    private var wakeTriggered = false

    override fun onCreate() {
        super.onCreate()
        val channelId = "fg_wake_word_status"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "F G Assistant voice service", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Visible status for F G Assistant wake phrase detection"
                }
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId)
            else Notification.Builder(this)
        val notification: Notification = builder
            .setContentTitle("F G Assistant is listening")
            .setContentText("Say ‘Hey F G’ to open your assistant. Tap to return to the app.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        startForeground(42, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        beginRecognition()
        return START_STICKY
    }

    private fun beginRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Speech recognition is unavailable on this device")
            stopSelf()
            return
        }
        try {
            recognizer?.destroy()
            recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            recognizer?.setRecognitionListener(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    private fun inspect(results: Bundle?) {
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (wakeTriggered) return
        val matched = phrases.any {
            val normalized = it.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").trim()
            normalized.contains("hey fg") || normalized.contains("hey f g") || normalized.contains("hey eff gee")
        }
        if (matched) {
            wakeTriggered = true
            listening = false
            recognizer?.cancel()
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("wake_phrase_detected", true)
            }
            startActivity(launch)
            updateNotification("Wake phrase detected — opening F G Assistant")
            handler.postDelayed({
                if (isListeningServiceActive()) {
                    wakeTriggered = false
                    beginRecognition()
                }
            }, 5000)
        }
    }

    private fun isListeningServiceActive() = !isDestroyed

    private fun scheduleRestart() {
        if (restarting || isDestroyed) return
        restarting = true
        handler.postDelayed({
            restarting = false
            if (!isDestroyed) beginRecognition()
        }, 1200)
    }

    private fun updateNotification(message: String) {
        val channelId = "fg_wake_word_status"
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId)
            else Notification.Builder(this)
        val notification = builder.setContentTitle("F G Assistant voice service")
            .setContentText(message).setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        getSystemService(NotificationManager::class.java).notify(42, notification)
    }

    override fun onReadyForSpeech(params: Bundle?) { listening = true }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { listening = false }
    override fun onError(error: Int) { listening = false; if (!wakeTriggered) scheduleRestart() }
    override fun onResults(results: Bundle?) { listening = false; inspect(results); if (!wakeTriggered && !restarting && !isDestroyed) scheduleRestart() }
    override fun onPartialResults(partialResults: Bundle?) { inspect(partialResults) }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
