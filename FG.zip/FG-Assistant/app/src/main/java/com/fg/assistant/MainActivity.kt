package com.fg.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var apiKeyInput: EditText
    private lateinit var commandInput: EditText
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("fg_assistant", MODE_PRIVATE) }
    private val model = "gemini-3.8-flash"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        tts = TextToSpeech(this, this)
        buildScreen()
        apiKeyInput.setText(prefs.getString("api_key", ""))
        status.text = "F G ready, Farid sir. Add your Gemini API key to begin."
        if (intent.getBooleanExtra("wake_phrase_detected", false)) {
            window.decorView.postDelayed({ startVoiceInput() }, 900)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF02070D.toInt())
        }

        val title = TextView(this).apply {
            text = "F G ASSISTANT"
            textSize = 25f
            setTextColor(0xFF25D9FF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val face = ImageView(this).apply {
            setImageResource(R.drawable.fg_face)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "F G Assistant holographic face"
        }
        root.addView(face, LinearLayout.LayoutParams(-1, 0, 2f))

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF55E8F5.toInt())
            setPadding(4, 12, 4, 12)
        }
        root.addView(status)

        val scroll = ScrollView(this)
        conversation = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFB7F7FF.toInt())
            setPadding(4, 8, 4, 8)
            text = "F G: Hello Farid sir. I am ready."
        }
        scroll.addView(conversation)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        apiKeyInput = EditText(this).apply {
            hint = "Paste Gemini API key"
            setSingleLine(true)
            setTextColor(-1)
            setHintTextColor(0xFF8298A5.toInt())
        }
        root.addView(apiKeyInput)

        val save = Button(this).apply {
            text = "SAVE API KEY"
            setOnClickListener {
                val key = apiKeyInput.text.toString().trim()
                if (key.isBlank()) {
                    status.text = "Please enter your API key."
                } else {
                    // Stored only in this app's private preferences. Do not share the APK with your key.
                    prefs.edit().putString("api_key", key).apply()
                    status.text = "API key saved on this device. Try a message."
                }
            }
        }
        root.addView(save)

        commandInput = EditText(this).apply {
            hint = "Type a command or question"
            setTextColor(-1)
            setHintTextColor(0xFF8298A5.toInt())
        }
        root.addView(commandInput)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply {
            text = "SEND"
            setOnClickListener { sendPrompt(commandInput.text.toString().trim()) }
        }
        val voice = Button(this).apply {
            text = "MIC"
            setOnClickListener { startVoiceInput() }
        }
        actions.addView(send, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)

        val automationTitle = TextView(this).apply {
            text = "ANDROID AUTOMATION"
            textSize = 14f
            setTextColor(0xFF25D9FF.toInt())
            setPadding(0, 12, 0, 4)
        }
        root.addView(automationTitle)

        val toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val appsButton = Button(this).apply {
            text = "APPS"
            setOnClickListener { showInstalledLaunchableApps() }
        }
        val dialButton = Button(this).apply {
            text = "DIAL"
            setOnClickListener { openDialer() }
        }
        val filesButton = Button(this).apply {
            text = "FILES"
            setOnClickListener { openFilePicker() }
        }
        toolsRow.addView(appsButton, LinearLayout.LayoutParams(0, -2, 1f))
        toolsRow.addView(dialButton, LinearLayout.LayoutParams(0, -2, 1f))
        toolsRow.addView(filesButton, LinearLayout.LayoutParams(0, -2, 1f))
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val searchButton = Button(this).apply {
            text = "WEB"
            setOnClickListener { runQuickCommand("search web") }
        }
        val cameraButton = Button(this).apply {
            text = "CAMERA"
            setOnClickListener { runQuickCommand("open camera") }
        }
        val smsButton = Button(this).apply {
            text = "SMS"
            setOnClickListener { runQuickCommand("compose sms") }
        }
        searchRow.addView(searchButton, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(cameraButton, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(smsButton, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(searchRow)

        val serviceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val wakeOn = Button(this).apply {
            text = "WAKE SERVICE ON"
            setOnClickListener { startWakeWordService() }
        }
        val wakeOff = Button(this).apply {
            text = "STOP SERVICE"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WakeWordService::class.java))
                status.text = "Wake service stopped."
            }
        }
        serviceRow.addView(wakeOn, LinearLayout.LayoutParams(0, -2, 1f))
        serviceRow.addView(wakeOff, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(serviceRow)

        val windowsInfo = TextView(this).apply {
            text = "Windows companion source: windows/FgAssistantCompanion"
            textSize = 12f
            setTextColor(0xFF8298A5.toInt())
            setPadding(4, 8, 4, 4)
        }
        root.addView(windowsInfo)
        setContentView(root)
    }

    private fun startWakeWordService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 202)
            status.text = "Allow microphone permission, then tap WAKE SERVICE ON again."
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 203)
            status.text = "Allow notifications, then tap WAKE SERVICE ON again."
            return
        }
        try {
            val intent = Intent(this, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "Wake service started. Persistent notification will remain visible."
        } catch (e: Exception) {
            status.text = "Could not start foreground service: ${e.localizedMessage}"
        }
    }

    private fun showInstalledLaunchableApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val labels = apps.map { it.loadLabel(pm).toString() }.distinct()
        android.app.AlertDialog.Builder(this)
            .setTitle("Open an app")
            .setItems(labels.toTypedArray()) { _, which ->
                val chosen = labels[which]
                val match = apps.firstOrNull { it.loadLabel(pm).toString() == chosen }
                val launch = match?.activityInfo?.let {
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(it.packageName, it.name)
                }
                if (launch != null) startActivity(launch)
            }.setNegativeButton("Close", null).show()
    }

    private fun openDialer() {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 104)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to F G Assistant")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
        try {
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            status.text = "Speech recognition is not available on this device."
        }
    }

    @Deprecated("Uses Android speech recognition activity for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            commandInput.setText(spoken)
            sendPrompt(spoken)
        }
    }

    private fun runQuickCommand(command: String) {
        when (command) {
            "search web" -> {
                commandInput.setText("search web ")
                commandInput.setSelection(commandInput.text.length)
                commandInput.requestFocus()
                status.text = "Enter what you want to search, then press SEND."
            }
            else -> handleLocalCommand(command)
        }
    }

    private fun handleLocalCommand(raw: String): Boolean {
        val original = raw.trim()
        val command = original.lowercase(Locale.ROOT)
        return try {
            when {
                command in listOf("camera", "open camera", "start camera", "take photo", "selfie") -> {
                    startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    localReply("Opening the camera. You control capture and saving.")
                    true
                }
                command in listOf("open video camera", "record video", "start video") -> {
                    startActivity(Intent("android.media.action.VIDEO_CAPTURE"))
                    localReply("Opening video capture.")
                    true
                }
                command in listOf("compose sms", "write sms", "open messages", "open sms") -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("sms:")))
                    localReply("Opening your SMS app. Review before sending.")
                    true
                }
                command.startsWith("send sms to ") || command.startsWith("text ") -> {
                    val payload = original.substringAfter(" to ", "").ifBlank {
                        original.removePrefix("text ").trim()
                    }
                    val number = payload.substringBefore(" ").trim()
                    if (number.isBlank()) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("sms:")))
                    } else {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("sms:${Uri.encode(number)}")))
                    }
                    localReply("Opening the message composer. Check the recipient and message before sending.")
                    true
                }
                command.startsWith("call ") || command.startsWith("dial ") -> {
                    val number = original.substringAfter(" ").trim()
                    if (number.isBlank()) openDialer()
                    else startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
                    localReply("Opening the dialer. You can review the number and place the call.")
                    true
                }
                command == "open contacts" || command == "contacts" || command == "show contacts" -> {
                    startActivity(Intent(Intent.ACTION_PICK, android.provider.ContactsContract.Contacts.CONTENT_URI))
                    localReply("Opening contacts. Choose a contact.")
                    true
                }
                command == "open settings" || command == "settings" -> {
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    localReply("Opening Android settings.")
                    true
                }
                command in listOf("open wifi settings", "wifi settings", "open wi-fi settings") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
                    localReply("Opening Wi-Fi settings.")
                    true
                }
                command in listOf("open bluetooth settings", "bluetooth settings") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
                    localReply("Opening Bluetooth settings.")
                    true
                }
                command in listOf("open display settings", "display settings") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS))
                    localReply("Opening display settings.")
                    true
                }
                command in listOf("open sound settings", "sound settings") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS))
                    localReply("Opening sound settings.")
                    true
                }
                command in listOf("open location settings", "location settings") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    localReply("Opening location settings.")
                    true
                }
                command == "open files" || command == "browse files" || command == "file manager" -> {
                    openFilePicker()
                    localReply("Opening the Android file picker.")
                    true
                }
                command in listOf("create folder", "new folder", "make folder") -> {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    startActivityForResult(intent, 105)
                    localReply("Choose the destination in the system folder picker, then create your folder there.")
                    true
                }
                command.startsWith("search web ") || command.startsWith("search for ") ||
                    command.startsWith("google ") -> {
                    val query = when {
                        command.startsWith("search web ") -> original.substring(11).trim()
                        command.startsWith("search for ") -> original.substring(11).trim()
                        else -> original.substring(7).trim()
                    }
                    startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query))
                    localReply("Searching the web for $query.")
                    true
                }
                command.startsWith("open website ") || command.startsWith("go to website ") -> {
                    val address = original.substringAfter("website ").trim()
                    val normalized = if (address.startsWith("http")) address else "https://$address"
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalized)))
                    localReply("Opening $address.")
                    true
                }
                command.startsWith("maps ") || command.startsWith("navigate to ") ||
                    command.startsWith("find ") -> {
                    val place = when {
                        command.startsWith("maps ") -> original.substring(5).trim()
                        command.startsWith("navigate to ") -> original.substring(12).trim()
                        else -> original.substring(5).trim()
                    }
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(place)}")))
                    localReply("Showing $place in maps.")
                    true
                }
                command in listOf("share location", "open location sharing") -> {
                    startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    localReply("Location settings opened. Share your location through an app you choose.")
                    true
                }
                command.startsWith("share ") -> {
                    val textToShare = original.substring(6).trim()
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, textToShare)
                    }
                    startActivity(Intent.createChooser(share, "Share using"))
                    localReply("Choose the app and recipient in the Android share sheet.")
                    true
                }
                command.startsWith("set alarm") || command.startsWith("alarm ") -> {
                    val alarm = Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                    startActivity(alarm)
                    localReply("Opening the clock app to set your alarm.")
                    true
                }
                command.startsWith("set timer") || command.startsWith("timer ") -> {
                    val timer = Intent(android.provider.AlarmClock.ACTION_SET_TIMER)
                    startActivity(timer)
                    localReply("Opening the clock app to set your timer.")
                    true
                }
                command.startsWith("open ") -> {
                    val requested = original.substringAfter("open ").trim()
                    if (launchAppByName(requested)) {
                        localReply("Opening $requested.")
                    } else {
                        localReply("I couldn't find a launchable app named $requested. Try the APPS button.")
                    }
                    true
                }
                command in listOf("open dialer", "dialer", "phone") -> {
                    openDialer()
                    localReply("Opening the phone dialer.")
                    true
                }
                else -> false
            }
        } catch (e: Exception) {
            localReply("I couldn't complete that action: ${e.localizedMessage ?: "not supported on this device"}")
            true
        }
    }

    private fun launchAppByName(requestedName: String): Boolean {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val target = apps.firstOrNull {
            it.loadLabel(pm).toString().equals(requestedName, ignoreCase = true)
        } ?: apps.firstOrNull {
            it.loadLabel(pm).toString().contains(requestedName, ignoreCase = true)
        } ?: return false

        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(target.activityInfo.packageName, target.activityInfo.name)
        startActivity(launch)
        return true
    }

    private fun localReply(message: String) {
        conversation.append("\n\nF G: $message")
        status.text = "F G ready."
        speak(message)
    }

    private fun sendPrompt(prompt: String) {
        if (prompt.isBlank()) {
            status.text = "Please type or speak a message."
            return
        }
        if (handleLocalCommand(prompt)) return
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "Add and save your Gemini API key first."
            return
        }
        conversation.append("\n\nFarid: $prompt")
        status.text = "F G is thinking..."
        commandInput.setText("")

        executor.execute {
            try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                val connection = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", key)
                }
                val body = JSONObject().apply {
                    put("contents", org.json.JSONArray().put(
                        JSONObject().put("role", "user").put(
                            "parts", org.json.JSONArray().put(
                                JSONObject().put("text",
                                    "You are F G Assistant, a respectful, friendly AI assistant for Farid Ghani. " +
                                    "Be honest that you are an AI assistant. Never claim to be Farid. " +
                                    "Answer in the language used by the user. User message: $prompt")
                            )
                        )
                    ))
                }
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val raw = stream.bufferedReader().use { it.readText() }
                connection.disconnect()

                val answer = if (code in 200..299) {
                    val json = JSONObject(raw)
                    json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                        .getJSONObject(0).optString("text", "I could not read the response.")
                } else {
                    "Gemini request failed (HTTP $code). Check API key, model access, quota, and internet."
                }
                runOnUiThread {
                    conversation.append("\n\nF G: $answer")
                    status.text = "F G ready."
                    speak(answer)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Connection error: ${e.localizedMessage ?: "check internet and API key"}"
                }
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "fg_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
