F G Assistant source fixes
==========================

Fixed Kotlin compile errors from the GitHub Actions log:
- Added MainActivity.runQuickCommand() for the WEB, CAMERA and SMS quick buttons.
- Replaced Service.isDestroyed references with a service lifecycle flag in WakeWordService.

Build:
- Upload the CONTENTS of the FG-Assistant folder to the repository root, or keep using
  your repository workflow that extracts this ZIP and finds settings.gradle.kts.
- The GitHub Actions workflow should align Java and Kotlin JVM targets to 17.
- This source archive has not been compiled or device-tested here.

Notes:
- The wake phrase listener relies on Android's speech recognition provider; it is not
  a dedicated offline wake-word model and availability/background behavior varies.
- Android system approval screens remain in control of calls, messages, files and settings.
