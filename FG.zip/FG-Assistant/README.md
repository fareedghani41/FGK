# F G Assistant — Android + Windows starter v0.3

Owner profile: Farid Ghani  
Android application ID: `com.fg.assistant`

## Android features in this package
- Kotlin Android app with the supplied holographic face image
- Gemini text chat using the official `generateContent` REST endpoint and `gemini-3.8-flash`
- User-started voice input and Android text-to-speech replies
- Optional visible foreground wake-phrase listener that detects variants of “Hey F G” using Android's speech-recognition service
- Basic local actions: launch installed apps, open dialer, open file picker, camera intent, SMS composer, web search, Android settings, Wi-Fi settings, and Bluetooth settings
- GitHub Actions workflow for a debug APK

## Wake phrase limitations
The wake phrase implementation uses the speech-recognition provider available on the phone; it is not a dedicated always-on acoustic wake-word model. Recognition availability, language support, network dependence of the selected recognizer, battery use, and TECNO/Android background restrictions can affect reliability. It starts only after the user turns it on in the app, displays a persistent notification, and can be stopped from the app. It does not secretly record or archive conversations.

## Windows companion status
A WPF Windows companion project is included under `windows/FgAssistantCompanion`, with a separate GitHub Actions workflow to publish a Windows x64 app. It currently provides a pairing-interface scaffold only. It does **not** yet establish an authenticated phone-to-PC connection or execute remote PC commands. A real remote-control channel requires a reviewed encrypted protocol, device identity verification, pairing and revocation, and end-to-end testing; this package must not be represented as having that feature completed.

## Phone automation limits
Android actions are launched through supported system intents and user-granted permissions. This starter does not silently read private WhatsApp/Instagram/Snapchat data, send messages as the owner, install/uninstall apps, bypass permission dialogs, disable Play Protect, or perform hidden monitoring. SMS opens the system composer for the user to review and send. App availability varies by device.

## Build APK on GitHub
1. Extract this ZIP.
2. Upload the **contents** of `FG-Assistant` to the repository root (not just the ZIP).
3. Open GitHub Actions and run **Build F G Assistant Android APK**.
4. Download the `FG-Assistant-debug-apk` artifact.

## Build Windows companion
Run the separate **Build F G Assistant Windows Companion** workflow and download the `FG-Assistant-Windows-x64` artifact. This is a starter UI, not a remote-control server.

## Gemini API key
Create a key in Google AI Studio and paste it into the app, then tap **SAVE API KEY**. The key is stored in app-private preferences on the device. Do not commit the key to GitHub, screenshots, or a shared APK. For a public release, use a secure backend proxy rather than distributing a personal API key inside an APK.

## Privacy and security
- Microphone use is user-initiated and shown by Android's foreground-service notification.
- Android permission prompts and Play Protect are not bypassed.
- The assistant identifies itself as an AI assistant and does not impersonate Farid.
- Remote device control is not included until secure pairing is implemented and tested.


## Android automation expansion (v0.4 source update)
Voice commands handled locally (where a matching Android handler exists):
- `open <app name>` — launches a matching installed launchable app
- `open camera`, `record video` — opens the system camera capture UI
- `call <number>` — opens the dialer with a number; does not place the call
- `open contacts` — opens the system contact picker
- `compose sms`, `text <number>` — opens the SMS composer; does not send automatically
- `search web <query>`, `google <query>` — opens web search
- `open website <domain>` — opens a browser
- `maps <place>`, `navigate to <place>` — opens a map search
- `open settings`, `wifi settings`, `bluetooth settings`, `display settings`, `sound settings`, `location settings`
- `open files` — launches Android's system document picker
- `create folder` — opens the system folder picker; user chooses where to create/manage folders
- `share <text>` — opens Android's share sheet
- `set alarm`, `set timer` — opens the system clock UI

These commands use Android intents and system pickers. Android may ask the user to choose an app or grant access. The assistant cannot silently read another app's private messages, bypass permissions, install/uninstall apps without system approval, or make calls/send messages invisibly. The system share, contact, file, dialer and messaging UIs remain in control.
